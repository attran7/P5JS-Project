var clouds = [];

function setup() {
  createCanvas(700, 700);
   textSize(20);
  for (var i = 0; i < 4; i++) {
    clouds[i] = new Bubble(); 
  }
  
}

function draw() {
  background(50,180,250,100);
  
  for (var i = 0; i < clouds.length; i++) {
    clouds[i].move();
    clouds[i].display();
  }
  
  //rectangles for exercises and faqs/settings
  stroke(10);
  rect(50,200,150,50,20);
  rect(50,275,150,50,20);
  rect(50,350,150,50,20);
  
  rect(50,475,150,50,20);
  rect(50,550,150,50,20);
  
  //rectangle with text
  rect(25,50,200,100);
  
   //text inside
  fill('black');
  text('Your Little Helper', 50,105);
}

function Bubble(){
  this.x = random(0, width);
  this.y = random(0, height);
  
  this.display = function() {
   stroke(255);
    strokeWeight(1);
    fill(255);
    ellipse(this.x, this.y, 24, 24);
    ellipse(this.x+10,this.y+10,24,24);
    ellipse(this.x+30,this.y+10,24,24);
    ellipse(this.x+30,this.y-10,24,24);
    ellipse(this.x+20,this.y-10,24,24);
    ellipse(this.x+40,this.y,24,24);
  }
  
  this.move = function() {
    this.x = this.x += 1 ;
    this.y = this.y + random(-1, 1);
    
    if(this.x >= width){
    this.x = 0;
    }
  }
}

